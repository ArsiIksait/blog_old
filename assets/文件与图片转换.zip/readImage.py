from PIL import Image
import sys

#PIL的Image读取图片像素点颜色值到文件中
def readImage(imagePath,outputPath):
    f = open(outputPath, 'w+')  
    im = Image.open(imagePath)
    rgb_im = im.convert('RGB')
    width, height = im.size
    for i in range(width):
        for j in range(height):
            r, g, b = rgb_im.getpixel((i, j))
            print(r, g, b,file=f)
readImage(sys.argv[1],sys.argv[2])

"""
————————————————
原文链接：http://www.xoxxoo.com/index/index/article/id/649
2021/08/11 (ArsiIksait Modified)
"""