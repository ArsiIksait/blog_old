from PIL import Image
import sys

def createImage(x,y,path,outputPath):
    im = Image.new("RGB", (x, y))
    file = open(path)
    
    for i in range(0, x):
        for j in range(0, y):
            line = file.readline().replace('(','').replace(')','')
            rgb = line.split(",") #分割
            im.putpixel((i, j), (int(rgb[0]), int(rgb[1]), int(rgb[2]))) #（i,j）为坐标，后面的是像素点
    im.save(outputPath)
createImage(int(sys.argv[1]),int(sys.argv[2]),sys.argv[3],sys.argv[4])

"""
————————————————
版权声明：本文为CSDN博主「Hydra.」的原创文章，遵循CC 4.0 BY-SA版权协议，转载请附上原文出处链接及本声明。
原文链接：https://blog.csdn.net/qq_40657585/article/details/84858709
2021/08/10 (ArsiIksait Modified)
"""