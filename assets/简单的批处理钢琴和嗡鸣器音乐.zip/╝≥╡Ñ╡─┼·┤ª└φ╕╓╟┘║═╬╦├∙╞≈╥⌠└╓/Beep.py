import winsound
import sys
try:
    winsound.Beep(int(sys.argv[1]),int(sys.argv[2]))#发出报警声(频率Hz 37~32767,持续时间ms)
except NameError:
    print("错误#NameError:缺少参数!\n参数1是频率,范围:37~32767Hz\t参数2是持续时间ms,1s=1000ms")
except IndexError:
    print("错误#IndexError:缺少参数!\n参数1是频率,范围:37~32767Hz\t参数2是持续时间ms,1s=1000ms")
except ValueError:
    print("错误#ValueError:两个参数中至少有一个无法识别,必须是int整形数!")